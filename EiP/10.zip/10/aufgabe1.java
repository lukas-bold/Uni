public class aufgabe1 {

	public static void main(String[] args) {
		System.out.print(	istQuadratzahl(4)	);
	}

	public static boolean istQuadratzahl(int zahl){

	}
	
	public static int[] fib(int n){

	}

	public static int[] countElements(int[] werte, int max, int numBuckets){

	}

}