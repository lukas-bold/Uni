public class Wuerfeln{

	  public static void main(String[] args){
		  muenzwurf(3);
                  wuerfeln(3,2);
	  }

	  /**Exponentialfunktion, die b^e berechnet..
             @return Die Funktion gibt den Wert b<SUP><SMALL>EXPONENT</SMALL></SUP> zur&uuml;ck.
	     @param b Basis
             @param n Exponent
          */
	  public static int exp(int b, int e){
		  //Hier Code ergaenzen 
	  }
	
	  /**Diese Methode gibt alle m&ouml;glichen Ergebni&szlig;equenzen beim n-maligen Werfen einer M&uuml;nze aus.
             @param n Anzahl der W&uuml;rfe
          */
	  public static void muenzwurf(int n){
		  //Hier Code ergaenzen 
	  }
	  
	  /**Diese Methode gibt alle m&ouml;glichen Ergebni&szlig;equenzen beim n-maligen W&uuml;rfeln eines k-seitigen W&uuml;rfels aus.
	     @param k Anzahl der Seiten des W&uuml;rfels
             @param n L&auml;nge der W&uuml;rfelsequenz
          */
	  public static void wuerfeln(int n, int k ){
                     //Hier Code ergaenzen 
	  }
	
}
